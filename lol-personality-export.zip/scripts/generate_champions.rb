#!/usr/bin/env ruby
# frozen_string_literal: true

require "json"

EN_PATH = "/tmp/lol-dd/en.json"
RO_PATH = "/tmp/lol-dd/ro.json"
UNIVERSE_PATH = "/Users/aeera/.cursor/projects/Users-aeera-lol-personality/agent-tools/f8576e8f-dff2-4b3d-b9be-5037b1060477.txt"
OUT_PATH = File.expand_path("../js/champions.js", __dir__)

REGION_TRAITS = {
  "demacia" => %w[honorable dutiful orderly protector],
  "noxus" => %w[ambitious ruthless strong],
  "ionia" => %w[spiritual balanced disciplined],
  "freljord" => %w[hardy primal tribal survivor],
  "piltover" => %w[inventive orderly ambitious],
  "zaun" => %w[inventive chaotic survivor],
  "bilgewater" => %w[free opportunistic chaotic],
  "shadow-isles" => %w[tragic haunted dark],
  "shurima" => %w[imperial ancient proud],
  "ixtal" => %w[nature isolated magical],
  "mount-targon" => %w[celestial destined spiritual],
  "void" => %w[hungry alien dark],
  "bandle-city" => %w[playful curious chaotic],
  "unaffiliated" => %w[independent],
}.freeze

CLASS_TRAITS = {
  "Tank" => %w[protector frontline durable],
  "Fighter" => %w[warrior frontline grit],
  "Assassin" => %w[lethal independent opportunistic],
  "Mage" => %w[magical knowledge],
  "Marksman" => %w[precise focused],
  "Support" => %w[caretaker team],
}.freeze

KEYWORDS = {
  "honorable" => %w[honor honoured honored justice righteous noble oath virtue],
  "dutiful" => %w[duty king queen prince princess crown soldier knight demacia],
  "ambitious" => %w[conquer empire ambition command noxus rise throne],
  "ruthless" => %w[ruthless brutal slaughter kill assassin murder],
  "chaotic" => %w[chaos chaotic mad insane wild reckless impuls explos],
  "independent" => %w[exile wander loner outcast unaffiliated own path],
  "protector" => %w[protect guardian shield defend save ward],
  "lethal" => %w[assassin silent blade dagger lethal deadly],
  "charming" => %w[charm seduc allur beauty love fascin],
  "inventive" => %w[invent hextech chemtech scientist engineer machine],
  "spiritual" => %w[spirit temple balance ionia monk],
  "tragic" => %w[tragic curse cursed imprison torment grief],
  "playful" => %w[playful trick mischief yordle fun joke],
  "curious" => %w[curious curiosity discovery seek],
  "haunted" => %w[shadow isles death undead haunt ghost ruination],
  "celestial" => %w[aspect celestial star targon divine god],
  "hungry" => %w[void hunger devour consume],
  "ancient" => %w[ancient immortal centuries millenni darkin ascended],
  "survivor" => %w[survive street underground zaun scrap],
  "free" => %w[pirate sea captain plunder bilgewater freedom],
  "primal" => %w[ice winter tribe hunt beast freljord],
  "nature" => %w[jungle elemental nature ixtal],
  "imperial" => %w[emperor empress empire shurima desert],
}.freeze

en = JSON.parse(File.read(EN_PATH))
ro = JSON.parse(File.read(RO_PATH))["data"]
universe = JSON.parse(File.read(UNIVERSE_PATH))
version = en["version"]

factions = {}
universe["champions"].each do |champ|
  factions[champ["slug"]] = champ["associated-faction-slug"]
end
factions["renata"] = "zaun"

def traits_from_text(text)
  hay = text.downcase
  found = []
  KEYWORDS.each do |trait, words|
    found << trait if words.any? { |w| hay.include?(w) }
  end
  found
end

def combat_style(info)
  attack = info["attack"].to_i
  magic = info["magic"].to_i
  defense = info["defense"].to_i
  return "tank" if defense >= 7 && defense >= attack && defense >= magic
  return "ap" if magic >= attack + 2
  return "ad" if attack >= magic + 2

  "hybrid"
end

champions = {}
en["data"].each do |id, champ|
  slug = id.downcase
  region = factions[slug] || "unaffiliated"
  classes = champ["tags"]
  info = champ["info"]
  range = champ["stats"]["attackrange"].to_i < 300 ? "melee" : "ranged"
  style = combat_style(info)
  traits = []
  traits.concat(REGION_TRAITS[region] || [])
  classes.each { |c| traits.concat(CLASS_TRAITS[c] || []) }
  traits.concat(traits_from_text("#{champ["title"]} #{champ["blurb"]}"))
  traits.uniq!

  ro_champ = ro[id] || {}
  champions[id] = {
    "id" => id,
    "name" => champ["name"],
    "title" => {
      "en" => champ["title"],
      "ro" => ro_champ["title"] || champ["title"],
    },
    "blurb" => {
      "en" => champ["blurb"],
      "ro" => ro_champ["blurb"] || champ["blurb"],
    },
    "classes" => classes,
    "region" => region,
    "range" => range,
    "style" => style,
    "traits" => traits,
  }
end

File.write(
  OUT_PATH,
  <<~JS
    const DDRAGON_VERSION = #{version.to_json};
    const champions = #{JSON.pretty_generate(champions)};
  JS
)

puts "Wrote #{champions.size} champions to #{OUT_PATH}"
puts "regions: #{champions.values.map { |c| c["region"] }.tally.sort}"
