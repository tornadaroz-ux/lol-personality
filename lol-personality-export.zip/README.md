# LoL Personality

A bilingual (RO/EN) League of Legends personality quiz: answer a few questions and get a matching champion.

How to use:
- Open `index.html` directly in a browser for a quick test.
- Or serve the folder with any static web server if you want a cleaner browser experience.

This version is built as a fully offline static export, so it works on both desktop and mobile devices without any internet connection or backend.

Export:
- The project is ready to be zipped and sent to friends.
- For a simple bundle, zip the project folder and open `index.html` in any browser.
